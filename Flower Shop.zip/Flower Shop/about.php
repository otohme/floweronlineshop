<?php

include 'connection.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <link rel="shortcut icon" href="images/icon.png" type="image/x-icon" />
   <title>About | Flourish</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/styles.css">

</head>
<body>
   <!--cursor effect -->
   <div class="cursor-1"></div>
   <div class="cursor-2"></div>

<?php include 'header.php'; ?>

<section class="headingabout">
    <h3>About Us</h3>
    <p> <a href="index.php">Home</a> | About </p>
</section>

<section class="about">
    <div class="flex" id="section-about1">

        <div class="image">
            <img src="images/aboutus.jpg" alt="">
        </div>

        <div class="content">
			<h3> <span class="typing-animation">Who are we?</span> </h3>
			<!-- Animated paragraph -->
			<p class="paragraph-animation">Flourish boutique, is a flower shop located in Beirut. 
				We do create fabulous bouquets, flower arrangements, weddings, diners, birthdays, engagements, new born… 
				We are a wholsale and Retail fresh cut flowers and pot plants supplier.<br><br>
				Our aim is to provide a comprehensive personal service, 
				we realise that today’s market is as competitive as ever, 
				and strive to keep our prices as low as possible and with that in mind we are pleased to offer a price promise, and will match any genuine like for like price.<br><br>
				We have an extensive range of products, including vases in every conceivable size and colour, candelabra, candles, shells, ribbons and one of the largest silk flower sections.</p> 
		</div>
		<style>
			/* Hide the cursor */
			.typing-cursor {
				display: none;
			}

			/* Apply the typing animation */
			.typing-animation {
				animation: typing 5s steps(7) infinite;
				display: inline-block;
				overflow: hidden;
				border-right: .15em solid orange;
			}

			/* Define the keyframes for the animation */
			@keyframes typing {
				0% { width: 0; }
				100% { width: 100%; }
			}
		</style>
		<style>
			/* Apply the animation to the text */
			.animation {
				color: red;
				animation: color-change 2s linear infinite;
			}

			/* Define the keyframes for the animation */
			@keyframes color-change {
				0% { color: #3D8DAE; }
				25% { color: #DF8453;; }
				50% { color: #E4A9A8; }
				75% { color: pink; }
				100% { color: red; }
			}

			/* Apply the animation to the paragraph */
			.paragraph-animation {
				color: blue;
				animation: color-change-2 6s linear infinite;
			}

			/* Define the keyframes for the paragraph animation */
			@keyframes color-change-2 {
				0% { color: #3D8DAE; }
				25% { color: #DF8453;; }
				50% { color: #E4A9A8; }
				75% { color: darkmagenta; }
				100% { color: red; }
			}
		</style>
    </div>
</section>

<section class="events">
	<h1 class="title"><span>Events</span> Gallery</h1>
	<div class="gallery">
		<div>
            <img src="events/1.jpg" alt=""> 
		</div>
		<div>
            <img  src="events/2.jpg" alt=""> 
		</div>
        <div>
			<img  src="events/3.jpg" alt=""> 
		</div>
        <div>
			<img  src="events/5.jpg" alt=""> 
		</div>
        <div>
			<img  src="events/8.jpg" alt=""> 
		</div>
        <div>
			<img  src="events/7.jpg" alt=""> 
		</div>
        <div>
			<img  src="events/4.jpg" alt=""> 
		</div>
		<div>
			<img  src="events/6.jpg" alt=""> 
		</div>
		<div>
			<img  src="events/9.jpg" alt=""> 
		</div>
	</div>
	<p><br>From receptions, and galas to corporate meetings, sporting events, and industry conventions, <span>Flourish Boutique</span> does it all. </br>
		We have a dedicated team of event specialists who focus exclusively on event services. Experienced with almost every style, venue, theme, and budget,<br> 
		the artists at <span>Flourish Boutique</span> make special events come alive all over Lebanon.</p>
		<div class="scrolldown">
</section>
<button onclick="topFunction()" id="myBtn" title="Go to top"><img src="images/top.png" /></button>
<!-- Loader -->
<div class="loader-container">
    <img src="images/loader.gif" alt=" " />
</div>

<?php include 'footer.php'; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="js/main.js"></script>
<script>
//Get the button
var mybutton = document.getElementById("myBtn");

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
</body>
</html>