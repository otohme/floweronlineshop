let userBox = document.querySelector('.header .flex .account-box');

 document.querySelector('#user-btn').onclick = () =>{
    userBox.classList.toggle('active');
    navbar.classList.remove('active');
 }

let navbar = document.querySelector('.header .flex .navbar');

 document.querySelector('#menu-btn').onclick = () =>{
     navbar.classList.toggle('active');
     userBox.classList.remove('active');
    }

window.onscroll = () =>{
     userBox.classList.remove('active');navbar.classList.remove('active');
}

//loader
 function loader(){
    document.querySelector('.loader-container').classList.add('fade-out');
  }
  
  function fadeOut(){
    setInterval(loader, 3000);
  }
  
  window.onload = fadeOut();

//cursor effect
  let cursor1 = document.querySelector('.cursor-1');
  let cursor2 = document.querySelector('.cursor-2');
  
  window.onmousemove = (e) =>{
      cursor1.style.top = e.pageY + 'px';
      cursor1.style.left = e.pageX + 'px';
      cursor2.style.top = e.pageY + 'px';
      cursor2.style.left = e.pageX + 'px';
  }
   function myFunction() {
        var element = document.body;
        element.classList.toggle("dark-mode");
     }
      
  document.querySelectorAll('a').forEach(links =>{
  
      links.onmouseenter = () =>{
          cursor1.classList.add('active');
          cursor2.classList.add('active');
      }
  
      links.onmouseleave = () =>{
          cursor1.classList.remove('active');
          cursor2.classList.remove('active');
      } 
  });
//what do we offer section effect
  $('.home-offer .button-container .btn').click(function(){

    let filter = $(this).attr('data-filter');

    if(filter == 'all'){
      $('.home-offer .box-container .box').show('400')
    }else{
      $('.home-offer .box-container .box').not('.'+filter).hide('200');
      $('.home-offer .box-container .box').filter('.'+filter).show('400');
    }

  });

  //subscribe
  const emailInput = document.getElementById('email-input');
  const subscribeBtn = document.getElementById('subscribe-btn');

  subscribeBtn.addEventListener('click', function() {
    const email = emailInput.value;
    subscribeToNewsletter(email);
  });

  function subscribeToNewsletter(email) {
    const url = `https://example.com/subscribe?email=${encodeURIComponent(email)}`;
    fetch(url, { method: 'POST' })
      .then(function(response) {
        if (response.ok) {
          console.log('Subscription successful');
          alert('You have successfully subscribed to our newsletter!');
        } else {
          console.error('Subscription error:', response.statusText);
          alert('There was an error subscribing to our newsletter. Please try again later.');
        }
      })
      .catch(function(error) {
        console.error('Subscription error:', error);
        alert('There was an error subscribing to our newsletter. Please try again later.');
      });
  }