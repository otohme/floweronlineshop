<?php

include 'connection.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
};

if(isset($_POST['add_to_wishlist'])){

    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];

    $check_wishlist_numbers = mysqli_query($conn, "SELECT * FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

    $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

    if(mysqli_num_rows($check_wishlist_numbers) > 0){
        $message[] = 'already added to wishlist';
    }elseif(mysqli_num_rows($check_cart_numbers) > 0){
        $message[] = 'already added to cart';
    }else{
        mysqli_query($conn, "INSERT INTO `wishlist`(user_id, pid, name, price, image) VALUES('$user_id', '$product_id', '$product_name', '$product_price', '$product_image')") or die('query failed');
        $message[] = 'product added to wishlist';
    }

}

if(isset($_POST['add_to_cart'])){

    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    $product_quantity = $_POST['product_quantity'];

    $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

    if(mysqli_num_rows($check_cart_numbers) > 0){
        $message[] = 'already added to cart';
    }else{

        $check_wishlist_numbers = mysqli_query($conn, "SELECT * FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

        if(mysqli_num_rows($check_wishlist_numbers) > 0){
            mysqli_query($conn, "DELETE FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');
        }

        mysqli_query($conn, "INSERT INTO `cart`(user_id, pid, name, price, quantity, image) VALUES('$user_id', '$product_id', '$product_name', '$product_price', '$product_quantity', '$product_image')") or die('query failed');
        $message[] = 'product added to cart';
    }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <link rel="shortcut icon" href="images/icon.png" type="image/x-icon" />
   <title>Shop | Flourish</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="css/styles.css">

   <script src="js/timer.js" defer></script>

</head>
<body>
<!--cursor effect -->
<div class="cursor-1"></div>
<div class="cursor-2"></div>

<?php include 'header.php'; ?>

<section class="headingshop">
    <h3>Our Shop</h3>
    <p> <a href="index.php">Home</a> | Shop </p>
</section>

<section class="shop">
    <div class="flex">
        <div class="content">
            <h1 class="pink">Fresh Flowers
            <img id="pink-flower" src ="images/pink.png">
            </h1>
            <h2 >From Our Garden to Your Table</h2>
            <p>Flowers are carefully selected and handpicked by expert florists<br>
            to bring smile and happiness.</p>
        </div>
        <div class="image">
            <img src="images/shop.jpg" alt="">
        </div>
    </div>
</section>
<section class="shop">
    <div class="flex">
        <div class="content">
            <h1 class="yellow">Best gifts
            <img id="yellow-flower" src="https://cdn.shopify.com/s/files/1/0439/7521/3208/files/img-01_130x.png?v=1614303583" alt="yellow-flower"> 
            </h1>
            <h2>Shop Our Products</h2>
            <p>All varieties of flowers available in different shapes and types <br>special hand-tied bouquet</p>
        </div>
    </div>
</section>
<section class="products"> 
    <div class="box-container">
      <?php
        $select_products = mysqli_query($conn, "SELECT * FROM `products` ");
        // Check if there are any products in the result set
        if(mysqli_num_rows($select_products) > 0){
            // Loop through each product in the result set

            while($fetch_products = mysqli_fetch_assoc($select_products)){
                    // Process each product and display it on the page
        ?>
        <form action="" method="POST" class="box">
        <input type="hidden" name="product_id" value="<?= $fetch_products['id']; ?>">
        <input type="hidden" name="product_name" value="<?= $fetch_products['name']; ?>">
        <input type="hidden" name="product_price" value="<?= $fetch_products['price']; ?>">
        <input type="hidden" name="product_image" value="<?= $fetch_products['image']; ?>">
        <button class="fas fa-heart" type="submit" name="add_to_wishlist"></button>
        <a href="view_page.php?pid=<?= $fetch_products['id']; ?>" class="fas fa-eye"></a>
        <img src="flowers/<?= $fetch_products['image']; ?>" alt="">
        <div class="name"><?php echo $fetch_products['name']; ?></div>
        
        <div class="flex">
        <div class="price"><span>$</span><?= $fetch_products['price']; ?></div>
            <input type="number" name="product_quantity" class="qty" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1">
        </div>

        <input type="submit" value="add to cart" class="btn" name="add_to_cart" >
        </form>
        <?php
        }
        }else{
        echo '<p class="empty">No products added yet!</p>';
        }
        ?>
    </div>
</section>

<section class="offers">
<div class="mothers-day-collection" >
        <section class="sale">
            <h1 class="red">SALE UP TO 20%<br>
            </h1>
            <div class="container">
                <div class="container-segment">
                    <div class="segment-title">Hours</div>
                    <div class="segment">
                        <div class="flip-card" data-hours-tens>
                            <div class="top">2</div>
                            <div class="bottom">2</div>
                        </div>
                        <div class="flip-card" data-hours-ones>
                            <div class="top">4</div>
                            <div class="bottom">4</div>
                        </div>
                    </div>
                </div>
                <div class="container-segment">
                    <div class="segment-title">Minutes</div>
                    <div class="segment">
                        <div class="flip-card" data-minutes-tens>
                            <div class="top">0</div>
                            <div class="bottom">0</div>
                        </div>
                        
                        <div class="flip-card" data-minutes-ones>
                            <div class="top">0</div>
                            <div class="bottom">0</div>
                        </div>
                    </div>
                </div>
                <div class="container-segment">
                    <div class="segment-title">Seconds</div>
                    <div class="segment">
                        <div class="flip-card" data-seconds-tens>
                            <div class="top">0</div>
                            <div class="bottom">0</div>
                        </div>
                        <div class="flip-card" data-seconds-ones>
                            <div class="top">0</div>
                            <div class="bottom">0</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <h2>Mother's Day Collection</h2>
    <p>Want to send Mom the best Mothers Day Flowers?<br> Flourish has stunning gifts she'll absolutely love!</p>                              
</div>
<section class="sales">
<div class="swiper products-slider">
    <div class="swiper-wrapper">
        <?php
            $select_products = mysqli_query($conn, "SELECT * FROM `products` ");
            // Check if there are any products in the result set
            if(mysqli_num_rows($select_products) > 0){
                // Loop through each product in the result set

                while($fetch_products = mysqli_fetch_assoc($select_products)){
                        // Process each product and display it on the page
            ?>
            <form action="" method="POST"class="swiper-slide slide">
            <input type="hidden" name="product_id" value="<?= $fetch_products['id']; ?>">
            <input type="hidden" name="product_name" value="<?= $fetch_products['name']; ?>">
            <input type="hidden" name="product_price" value="<?= $fetch_products['price']; ?>">
            <input type="hidden" name="product_image" value="<?= $fetch_products['image']; ?>">
            <button class="fas fa-heart" type="submit" name="add_to_wishlist"></button>
            <a href="view_page.php?pid=<?= $fetch_products['id']; ?>" class="fas fa-eye"></a>
            <img src="flowers/<?= $fetch_products['image']; ?>" alt="">
            <div class="name"><?php echo $fetch_products['name']; ?></div>
            
            <div class="flex">
            <div class="price"><span>$</span><?= $fetch_products['price']; ?></div>
                <input type="number" name="product_quantity" class="qty" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1">
            </div>

            <input type="submit" value="add to cart" class="btn" name="add_to_cart" >
            </form>
            <?php
            }
            }else{
            echo '<p class="empty">No products added yet!</p>';
            }
        ?>
        </div>
    <div class="swiper-pagination"></div>
    </div>
</section>
</section>

<section class="garden">        
    <div class="content">
        <h1>Order Now
            <img id="purple-flower" src ="images/purple.png">
        </h1>
        <h2> Our Garden Collection</h2>
        <p>Blossoms live in every color and aroma. <br>
            Beautifully share your emotions with our garden flowers.</p>
    </div>

    <div class="flex">
        <div class="image">
            <img src="https://cdn.shopify.com/s/files/1/0439/7521/3208/files/girlflower_900x.jpg?v=1614303610" id="flower_girl_img" alt="" />
        </div>
        <div class="steps-shop">
            <div class="step">
                <h4>1- Choose Flower</h4>
                <p>Choose the type of flower that you want based on factors such as personal preference, occasion, and availability.</p>
            </div>  
                
            <div class="step">
                <h4>2- Place an Order</h4>
                <p>Provide the florist with the specific type of flower, quantity, delivery address, and any additional requests or instructions to complete the order.</p>
            </div>  
                
            <div class="step">
                <h4>3- Get Plants Delivered</h4>
                <p>Wait for the delivery confirmation and ensure that someone is available to receive the plant, and take care of it accordingly.</p>
            </div>
        </div>
    </div>
    <div class="scrolldown">
</section>
<button onclick="topFunction()" id="myBtn" title="Go to top"><img src="images/top.png" /></button>
<!-- Loader -->
<div class="loader-container">
    <img src="images/loader.gif" alt=" " />
</div>

<?php include 'footer.php'; ?>

<!-- Swiper -->
<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
<script src="js/main.js"></script>

<script>

var swiper = new Swiper(".home-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
    },
});

 var swiper = new Swiper(".category-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
   breakpoints: {
      0: {
         slidesPerView: 2,
       },
      650: {
        slidesPerView: 3,
      },
      768: {
        slidesPerView: 4,
      },
      1024: {
        slidesPerView: 5,
      },
   },
});

var swiper = new Swiper(".products-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
   breakpoints: {
      550: {
        slidesPerView: 2,
      },
      768: {
        slidesPerView: 2,
      },
      1024: {
        slidesPerView: 3,
      },
   },
});

</script>

<script>
//Get the button
var mybutton = document.getElementById("myBtn");

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
</body>
</html>


