<?php
include 'connection.php';


session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <link rel="shortcut icon" href="images/icon.png" type="image/x-icon" />
   <title>Blog | Flourist</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/styles.css">

</head>
<body>
    <div class="cursor-1"></div>
    <div class="cursor-2"></div>

<?php include 'header.php'; ?>

<section class="headingblog">
    <h3  >Our Blog</h3>
    <p> <a href="index.php">Home</a> | Blog </p>
</section>

<section class="blog">

    <div class="flex">

        <div class="image">
            <img src="flowers/lillies.jpg" alt="">
        </div>

        <div class="content">
            <h3>Rose Lilies | Cut Flower Facts <br>(Pollen Free Lilies)</h3>
            <p><i>July 2, 2022 By </i>RONA</p>
            <p>If you love lilies but you’re concerned about getting lily pollen stains on your clothes or you find their scent too overpowering, then my latest video is perfect for you. I tell you all about a special Oriental lily called a Rose Lily. 
                Simply head over to my YouTube channel to watch the video.…</p>
            <a href="https://flowerona.com/rose-lilies-cut-flower-facts-pollen-free-lilies/" class="btn" target="_blank">Read More</a>
        </div>

    </div>

    <div class="flex">

        <div class="content">
            <h3>Hand-Tied Bouquet Demo & Interview with Michaela Bunting</h3>
            <p><i>October 12, 2022 By </i>RONA</p>
            <p>A Hand-Tied Bouquet Demo has been uploaded to my YouTube channel today! I’m so thrilled to feature this extra special video, where you’ll learn how to make this beautiful autumn hand-tied bouquet above.
                Michaela Bunting from Planting with Michaela demonstrates how to create this seasonal flower arrangement. 
                She talks you through the different types of flowers and foliage to use. 
                Then she goes into detail about how to make your bouquet using spiral and threading techniques, together with how to gift wrap your finished design!…</p>
            <a href="https://flowerona.com/hand-tied-bouquet-demo-interview-with-michaela-bunting/" class="btn" target="_blank">Read More</a>
        </div>

        <div class="image">
            <img src="flowers/bouquet.jpg" alt="">
        </div>

    </div>

    <div class="flex">

        <div class="image">
            <img src="flowers/british.png" alt="">
        </div>

        <div class="content">
            <h3>British Cut Flowers at the RHS Hampton Court Palace Garden Festival</h3>
            <p><i>July 2, 2022 By </i>RONA</p>
            <p>British cut flowers will be taking centre stage at the RHS Flower School at the RHS Hampton Court Palace Garden Festival this coming week! From July 4th-9th, a dedicated flower-filled marquee will host free floral demonstrations and hands-on workshops sharing the beauty of homegrown blooms.…
                </p>
            <a href="https://flowerona.com/british-cut-flowers-at-the-rhs-hampton-court-palace-garden-festival/" class="btn" target="_blank" >Read More</a>
        </div>

    </div>

</section>
<section class="subscribe">

   <form class="content">
      <h3>JOIN THE COMMUNITY!</h3>
      <i>Subscribe to receive inspirational content to help you grow your business.</i><br>
      <input type="text" placeholder="First Name">
      <input type="email" id="email-input" placeholder="E-mail Adrres" required>
      <button id="subscribe-btn" class="option-btn">Subscribe</button>
   </form>

   <div class="scrolldown">
</section>
<button onclick="topFunction()" id="myBtn" title="Go to top"><img src="images/top.png" /></button>
<!-- Loader -->
<div class="loader-container">
    <img src="images/loader.gif" alt=" " />
</div>

<?php include 'footer.php'; ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="js/main.js"></script>
<script>
//Get the button
var mybutton = document.getElementById("myBtn");

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
</body>
</html>


