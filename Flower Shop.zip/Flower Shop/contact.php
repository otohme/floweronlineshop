<?php

include 'connection.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
};

if(isset($_POST['send'])){

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $number = mysqli_real_escape_string($conn, $_POST['number']);
    $msg = mysqli_real_escape_string($conn, $_POST['message']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);


    $select_message = mysqli_query($conn, "SELECT * FROM `message` WHERE name = '$name' AND email = '$email' AND number = '$number' AND message = '$msg' AND subject = '$subject')") or die('Query Failed');

    if(mysqli_num_rows($select_message) > 0){
        $message[] = 'Message sent already!';
    }else{
        mysqli_query($conn, "INSERT INTO `message`(user_id, name, email, number, message, subject) VALUES('$user_id', '$name', '$email', '$number', '$msg', '$subject')") or die('Query Failed');
        $message[] = 'Message sent successfully!';
    }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <link rel="shortcut icon" href="images/icon.png" type="image/x-icon" />
   <title>Contact | Flourish</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/styles.css">

</head>
<body>
    <div class="cursor-1"></div>
    <div class="cursor-2"></div>
    <?php include 'header.php'; ?>

    <section class="headingcontact">
        <h3>contact us</h3>
        <p> <a href="index.php">Home</a> | Contact </p>
    </section>

    <section class="contact">

    <div class="row">

        <div class="info-container">

            <h1> Get in Touch</h1>

            <p>Our customer services team is here for you. 
                <br>Have questions? Prefer to order by Phone? 
                <br>Please call us 8AM - 8PM Beirut Time. </p>
            <div class="box-container">

                <div class="box">
                    <i class="fas fa-map"></i>
                    <div class="info">
                        <h3>Address :</h3>
                        <p>Beirut, Lebanon - 2038 3054</p>
                    </div>
                </div>

                <div class="box">
                    <i class="fas fa-envelope"></i>
                    <div class="info">
                        <h3>Email :</h3>
                        <p>Flourish@gmail.com</p>
                    </div>
                </div>

                <div class="box">
                    <i class="fas fa-phone"></i>
                    <div class="info">
                        <h3>Phone Number :</h3>
                        <p>+961-00-000000</p>
                    </div>
                </div>

            </div>

            <div class="share">
                <a href="https://www.facebook.com/" target="_blank" class="fab fa-facebook-square"></a>
                <a href="https://www.instagram.com/" target="_blank" class="fab fa-instagram"></a>
                <a href="https://www.snapchat.com/" target="_blank" class="fab fa-snapchat-ghost"></a>
                <a href="https://wa.me/96170021064/" target="_blank" class="fab fa-whatsapp"></a>
            </div>

        </div>

        <form action="" method="POST">

            <div class="inputBox">
                <input type="text"  name="name" placeholder="Name" required>
                <input type="number" name="number" placeholder="Number" required>
            </div>

            <div class="inputBox">
                <input type="email" name="email" placeholder="Email" required>
                <input type="text" name="subject" placeholder="Subject">
            </div>

            <textarea name="message" placeholder="Type here..." cols="30" rows="10"></textarea>

            <input type="submit" name="send" value="send message" class="btn">

        </form>

    </div>
</section>
<!-- Loader -->
<div class="loader-container">
    <img src="images/loader.gif" alt=" " />
</div>

<?php include 'footer.php'; ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>