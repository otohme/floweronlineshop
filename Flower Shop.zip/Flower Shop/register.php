<?php

include 'connection.php';
// Starts a new or resumes an existing session
session_Start();

// Check if the form has been submitted
if(isset($_POST['submit'])){

   // Sanitize and escape user inputs
   $filter_name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
   $name = mysqli_real_escape_string($conn, $filter_name);
   $filter_email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
   $email = mysqli_real_escape_string($conn, $filter_email);
   $filter_pass = filter_var($_POST['pass'], FILTER_SANITIZE_STRING);
   $pass = mysqli_real_escape_string($conn, md5($filter_pass));
   $filter_cpass = filter_var($_POST['cpass'], FILTER_SANITIZE_STRING);
   $cpass = mysqli_real_escape_string($conn, md5($filter_cpass));

   $select_users = mysqli_query($conn, "SELECT * FROM `users` WHERE email = '$email'") or die('Query Failed');

   if(mysqli_num_rows($select_users) > 0){ // Check if the user already exists in the database
      $message[] = 'User already exist!';
   }else{
      if($pass != $cpass){ // Check if the password and confirm password fields match
         $message[] = 'Uh Oh! Password and Confirm Password do not match!';
      }else{
         // Insert the user's information into the database if there are no errors
         mysqli_query($conn, "INSERT INTO `users`(name, email, password) VALUES('$name', '$email', '$pass')") or die('Query Failed');
         $message[] = 'Registered Successfully!';
         header('location:login.php'); // Redirect the user to the login page
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <link rel="shortcut icon" href="images/icon.png" type="image/x-icon" />
   <title>Register</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/styles.css">

</head>
<body>

<?php
//check if the $message variable is set and not null
if(isset($message)){
   foreach($message as $message){//loop through each message in the $message array
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>
   
<section class="form-container">

   <form action="" method="POST">
      <h3>Be part of <span>Flourish's</span> Family </h3>
      
      <label for="username" class="label">Username*:</label>
      <input type="text" name="name" class="box" placeholder="Username here" required>
      <label for="email" class="label">E-mail*:</label>
      <input type="email" name="email" class="box" id="email" placeholder="example@example.example" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
      <label for="password" class="label">Password*:</label>
      <input type="password" name="pass" class="box" placeholder="Password here" required>
      <label for="password" class="label">Confirm Password*:</label>
      <input type="password" name="cpass" class="box" placeholder="Re-enter your Password" required>

      <input type="submit" class="btn" name="submit" value="Register">

      <p>Already have an account? <a href="login.php">Login</a></p>
   </form>

</section>

<!-- custom scripts  -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>