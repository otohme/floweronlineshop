<?php

include 'connection.php';
// Starts a new or resumes an existing session
session_Start();

// Check if the form has been submitted
if(isset($_POST['submit'])){
   
   // Sanitize and escape user inputs
   $filter_email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
   $email = mysqli_real_escape_string($conn, $filter_email);
   $filter_pass = filter_var($_POST['pass'], FILTER_SANITIZE_STRING);
   $pass = mysqli_real_escape_string($conn, md5($filter_pass));

   $select_users = mysqli_query($conn, "SELECT * FROM `users` WHERE email = '$email' AND password = '$pass'") or die('Query Failed');

   // Check if user is registered
   if(mysqli_num_rows($select_users) > 0){
      $row = mysqli_fetch_assoc($select_users);

      // If the user is an admin, set session variables and redirect to the admin page
      if($row['user_type'] == 'admin'){

         $_SESSION['admin_name'] = $row['name'];
         $_SESSION['admin_email'] = $row['email'];
         $_SESSION['admin_id'] = $row['id'];
         header('location:admin/admin_page.php');

      }
      // If the user is a regular user, set session variables and redirect to the home page
      else if($row['user_type'] == 'user'){

         $_SESSION['user_name'] = $row['name'];
         $_SESSION['user_email'] = $row['email'];
         $_SESSION['user_id'] = $row['id'];
         header('location:index.php');

      }else{
         $message[] = 'No user found!';
      }

   }else{
      $message[] = 'Incorrect e-mail or password!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <link rel="shortcut icon" href="images/icon.png" type="image/x-icon" />
   <title>Login</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/styles.css">

</head>
<body>
<?php
//check if the $message variable is set and not null
if(isset($message)){
   foreach($message as $message){//loop through each message in the $message array
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>
   
<section class="form-container">
   <form action="" method="POST">
      <h3>Login</h3>

      <label for="email" class="label">E-mail*:</label>
      <input type="email" name="email" class="box" placeholder="example@example.example" required>
      <label for="password" class="label">Password*:</label>
      <input type="password" name="pass" class="box" placeholder="Password here" required>
      <input type="submit" class="btn" name="submit" value="Login">
      
      <p>Don't have an account? <a href="register.php">Register Now</a></p>
   </form>

</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>