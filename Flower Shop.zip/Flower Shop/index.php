<?php

include 'connection.php';
// Start a new or resume an existing session
session_start();

// Store/Retrieve the session's user ID in a local variable
$user_id = $_SESSION['user_id']; 

// Make sure the user is logged in before continuing
if(!isset($user_id)){
   header('location:login.php');
}

// Check if the user has selected the 'add to wishlist' button
if(isset($_POST['add_to_wishlist'])){

   // Code to add the item to the user's wishlist
   $product_id = $_POST['product_id'];
   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];

   // Retrieve all rows from the 'wishlist' table where the product name matches '$product_name' and user_id matches '$user_id'
   $check_wishlist_numbers = mysqli_query($conn, "SELECT * FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');
   
   // Check if the product has already been added to the user's wishlist
   if(mysqli_num_rows($check_wishlist_numbers) > 0){
       $message[] = 'Already added to wishlist';
   }else{
      // Add the product to the wishlist table
       mysqli_query($conn, "INSERT INTO `wishlist`(user_id, pid, name, price, image) VALUES('$user_id', '$product_id', '$product_name', '$product_price', '$product_image')") or die('query failed');
       $message[] = 'Product added to wishlist';
   }
}

// Check if the user has selected the 'add to cart' button
if(isset($_POST['add_to_cart'])){

   // Code to add the selected product to the user's cart
   $product_id = $_POST['product_id'];
   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   $product_quantity = $_POST['product_quantity'];

   // Retrieve all rows from the 'cart' table where the product name matches '$product_name' and user_id matches '$user_id'
   $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

   // Check if the product has already been added to the user's cart
   if(mysqli_num_rows($check_cart_numbers) > 0){
       $message[] = 'Already added to cart!';
   }else{
       $check_wishlist_numbers = mysqli_query($conn, "SELECT * FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');
      
       // Check if the product is already in the user's wishlist and remove it if it is
       if(mysqli_num_rows($check_wishlist_numbers) > 0){
           mysqli_query($conn, "DELETE FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');
       }
      // Add the product to the user's cart
       mysqli_query($conn, "INSERT INTO `cart`(user_id, pid, name, price, quantity, image) VALUES('$user_id', '$product_id', '$product_name', '$product_price', '$product_quantity', '$product_image')") or die('query failed');
       $message[] = 'Product added to cart';
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
   <link rel="shortcut icon" href="images/icon.png" type="image/x-icon" />
   <title>Home | Flourish</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/styles.css">

</head>
<body>
   <!--cursor effect -->
   <div class="cursor-1"></div>
   <div class="cursor-2"></div>

<?php include 'header.php'; ?>

<!-- heading section -->
<section class="home">
   <div class="content">
      <h3>Welcome!</h3>
      <p>Ready to experience the difference that Flourish can make? <br> Browse our collection of floral arrangements 
      or contact us to discuss your unique needs. We look forward to working with you!</p>
      <a href="about.php" class="btn">About Us</a>
   </div>
   <div class="scrolldown">
</section>
<button onclick="topFunction()" id="myBtn" title="Go to top"><img src="images/top.png" /></button>

<!-- products section -->
<section class="products">
   <h1 class="title"><span>Spring </span>Collection</h1>
      <div class="box-container">
      <?php
      include 'connection.php';
      $select_products = mysqli_query($conn, "SELECT * FROM `products` LIMIT 3");
      // Check if there are any products in the result set
      if(mysqli_num_rows($select_products) > 0){
            // Loop through each product in the result set

            while($fetch_products = mysqli_fetch_assoc($select_products)){
                     // Process each product and display it on the page
      ?>
      <form action="" method="POST" class="box">
         <input type="hidden" name="product_id" value="<?= $fetch_products['id']; ?>">
         <input type="hidden" name="product_name" value="<?= $fetch_products['name']; ?>">
         <input type="hidden" name="product_price" value="<?= $fetch_products['price']; ?>">
         <input type="hidden" name="product_image" value="<?= $fetch_products['image']; ?>">
         <button class="fas fa-heart" type="submit" name="add_to_wishlist"></button>
         <a href="view_page.php?pid=<?= $fetch_products['id']; ?>" class="fas fa-eye"></a>
         <img src="flowers/<?= $fetch_products['image']; ?>" alt="">
         <div class="name"><?php echo $fetch_products['name']; ?></div>
         
         <div class="flex">
         <div class="price"><span>$</span><?= $fetch_products['price']; ?></div>
            <input type="number" name="product_quantity" class="qty" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1">
         </div>

         <input type="submit" value="add to cart" class="btn" name="add_to_cart" >
      </form>
      <?php
         }
      }else{
         echo '<p class="empty">No products added yet!</p>';
      }
      // Free up memory
      mysqli_free_result($select_products);
      // Close db connection
      mysqli_close($conn);
      ?>
      </div>
   <div class="more-btn">
      <a href="shop.php" class="option-btn">check more</a>
   </div>
</section>

<!-- What we offer section -->
<section class="home-offer">
   <h1 class="title">What We <span>Offer</span></h1>

   <div class="box-container">
   <div class="box">
      <img src="flowers/arrangements.jpg" alt="">
      <h3>BOUQUETS</h3>
      <div class="content">
         <p>We make up arrangements to your requirements with our selection of flowers and roses designs.</p>
         <a href="about.php#events">View Gallery</a>
      </div>
   </div>

   <div class="box">
      <img src="flowers/funerals.jpg" alt="">
      <h3> FUNERALS </h3>
      <div class="content">   
         <p>We are here to share a tribute that communicates one's sympathy in a heartfelt manner.</p>
         <a href="about.php#events">View Gallery</a>
      </div>
   </div>

   <div class="box">
   <img src="flowers/wedding.jpg" alt="">
      <h3> WEDDING FLOWERS </h3>
      <div class="content">
         <p>We offer a full wedding service, including: bridal bouquets and table decorations and much more.</p>
         <a href="about.php">View Gallery</a>
      </div>
   </div>

   <div class="box">
   <img src="flowers/events.jpg" alt="">
      <h3> SPECIAL OCCASIONS </h3>
      <div class="content">
         <p>Our vision is to capture a message, display a theme and inspire the crowd.Social events, gala dinners…</p>
         <a href="about.php#events">View Gallery</a>
      </div>
   </div>
</section>

<!-- why choose us section -->
<section class="home-whyus">
   <h1 class="title">Why Choose <span>Flourish</span></h1>
   <div id="whyus">
      <div class="whyus">
         <img alt="" src="images/whyus.png">
      </div>
      <div class="content">
         <p>Our talented and friendly team of designers are floral experts with a passion for making your vision come true.<br> 
         Clean, simple and elegant hand tied bouquets are always ready to go, <br>
         but what we love most is collaborating with our clients to custom-design a bouquet or arrangement to suit your style, and your needs!</p>
         <a href="about.php#events" class="btn">Events Gallery</a>
      </div>
   </div>
</section>

<!-- counter section -->
<section class="counter">
   <div class="box-container">

      <div class="box" data-aos="fade-up">
         <i class="fas fa-truck"></i>
         <span>24/7</span>
         <h3>Free Delivery</h3>
      </div>

      <div class="box" data-aos="fade-up">
         <i class="fas fa-usd"></i>
         <span>Cash | Card</span>
         <h3>Easy Payments</h3>
      </div>

      <div class="box" data-aos="fade-up">
         <i class="fas fa-smile"></i>
         <span>Unique Assistance</span>
         <h3>Happy Customers</h3>
      </div>

      <div class="box" data-aos="fade-up">
         <i class="fas fa-hand-holding"></i>
         <span>Field-to-Vase</span>
         <h3>Freshly Picked</h3>
      </div>
   </div>
</section>

<!-- contact us section -->
<section class="home-contact">

   <div class="content">
      <h3>Any Questions?</h3>
      <p>If you have any questions or would like to place an order, 
         please don't hesitate to get in touch with us.</p>
      <a href="contact.php" class="btn">contact us</a>
   </div>

</section>

<!-- Loader -->
<div class="loader-container">
    <img src="images/loader.gif" alt=" " />
</div>

<?php include 'footer.php'; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="js/main.js"></script>
<script>
//Get the button
var mybutton = document.getElementById("myBtn");

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
</body>
</html>